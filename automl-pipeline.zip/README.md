# AutoML Pipeline

Run:
1. python src/train.py --data data/sample.csv --trials 20
2. uvicorn src.serve:app --reload
