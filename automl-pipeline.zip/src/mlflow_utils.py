import mlflow
from config import MLFLOW_TRACKING_URI, MLFLOW_EXPERIMENT

mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
mlflow.set_experiment(MLFLOW_EXPERIMENT)

def start_run(name=None):
    return mlflow.start_run(run_name=name)

def log_model_and_metrics(model, name, metrics, preprocessor=None, registered_model_name=None):
    import mlflow.sklearn
    from sklearn.pipeline import Pipeline
    with start_run(name):
        mlflow.log_metrics(metrics)
        try: mlflow.log_params(model.get_params())
        except: pass
        if preprocessor:
            pipe = Pipeline([("pre", preprocessor), ("model", model)])
            mlflow.sklearn.log_model(pipe, "model", registered_model_name=registered_model_name)
        else:
            mlflow.sklearn.log_model(model, "model", registered_model_name=registered_model_name)
