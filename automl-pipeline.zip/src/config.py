from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MLFLOW_TRACKING_URI = os.getenv("MLFLOW_TRACKING_URI", "http://127.0.0.1:5000")
MLFLOW_EXPERIMENT = os.getenv("MLFLOW_EXPERIMENT", "automl_pipeline_experiment")
RANDOM_SEED = int(os.getenv("RANDOM_SEED", 42))
TARGET_COL = os.getenv("TARGET_COL", "target")
