import pandas as pd
from sklearn.model_selection import train_test_split
from config import DATA_DIR, TARGET_COL, RANDOM_SEED
from pathlib import Path

def load_data(file_path=None):
    if file_path:
        return pd.read_csv(file_path)
    return pd.read_csv(DATA_DIR / "sample.csv")

def basic_cleaning(df):
    df = df.drop_duplicates()
    for col in df.select_dtypes(include=["number"]).columns:
        df[col] = df[col].fillna(df[col].median())
    for col in df.select_dtypes(exclude=["number"]).columns:
        df[col] = df[col].fillna(df[col].mode().iloc[0] if not df[col].mode().empty else "")
    return df

def split_data(df, test_size=0.2, val_size=0.1, random_state=RANDOM_SEED):
    X = df.drop(columns=[TARGET_COL])
    y = df[TARGET_COL]
    X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=test_size+val_size, random_state=random_state)
    rel = val_size/(test_size+val_size)
    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=rel, random_state=random_state)
    return X_train, X_val, X_test, y_train, y_val, y_test
