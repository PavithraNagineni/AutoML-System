from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC

def get_model_candidates():
    return {
        "random_forest": RandomForestClassifier(random_state=42),
        "xgboost": XGBClassifier(eval_metric="logloss", use_label_encoder=False),
        "logistic_regression": LogisticRegression(max_iter=1000),
        "svm": SVC(probability=True)
    }
